﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tower : MonoBehaviour {
	
	public Transform target;
	public GameObject head;
	public string EnemyTag = "Enemy";
	public float range = 4.5f;
	public float fireRate = 1f;

	// Use this for initialization
	void Start () 
	{
		InvokeRepeating ("UpdateTarget", 0f, 0.5f);
	}

	void UpdateTarget()
	{
		GameObject[] enemies = GameObject.FindGameObjectsWithTag (EnemyTag);

		float shortestDistance = Mathf.Infinity;
		GameObject nearestEnemy = null;

		foreach (GameObject enemy in enemies) 
		{
			float distanceToEnemy = Vector3.Distance (transform.position, enemy.transform.position);
			if (distanceToEnemy < shortestDistance) 
			{
				shortestDistance = distanceToEnemy;
				nearestEnemy = enemy;
			}
		}

		if (nearestEnemy != null && shortestDistance <= range) 
		{
			target = nearestEnemy.transform;
		}
	}
	
	// Update is called once per frame
	void Update () 
	{
		if (target == null)
			return;

		float fireCountdown = fireRate;
		fireCountdown--;

		Vector3 dir = target.position - head.transform.position;
		Quaternion lookRotation = Quaternion.LookRotation (dir);
		Vector3 rotation = Quaternion.Lerp(head.transform.rotation, lookRotation, Time.deltaTime).eulerAngles;
		head.transform.rotation = Quaternion.Euler (rotation.x, rotation.y, rotation.z);

		if (fireCountdown <= 0f) 
		{
			Shoot (dir);
			fireCountdown = 1f / fireRate;
		}

		fireCountdown -= Time.deltaTime;
	}

	void OnDrawGizmosSelected()
	{
		Gizmos.color = Color.red;
		Gizmos.DrawWireSphere (transform.position, range);
	}

	void Shoot(Vector3 dir)
	{
		RaycastHit hit;

		Ray ray = new Ray (head.transform.position, dir);

		Debug.DrawRay (head.transform.position, dir);

		if (Physics.Raycast (ray, out hit)) 
		{
			print ("Ray " + hit.collider.gameObject.tag);
			if (hit.collider.gameObject.tag == EnemyTag)
			{
				print ("Got it");
			}
		}
	}
}
