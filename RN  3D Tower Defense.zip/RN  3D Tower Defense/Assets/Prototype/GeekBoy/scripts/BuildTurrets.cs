﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BuildTurrets : MonoBehaviour
{

    public GameObject turret;
    Transform turretPos;
    public bool buildTurret;
    [Range(0,16)]
    public int maxBuildTurrets = 4;
    public GameObject[] aktiveObjects;
    int aktiveTurretsNumber = 0;
    

    private void Awake()
    {
        aktiveObjects = new GameObject[maxBuildTurrets];
        turretPos = turret.transform;
    }

    void Start()
    {

    }

    void Update()
    {
        if (buildTurret)
        {
            setPos(turretPos);
        }
    }

    /// <summary>
    /// Used to set the position of an object equal to the one of a "platform" using Raycast, and add the Object to the aktiveObjects-Array
    /// </summary>
    /// <param name="objTrans"></param>
    void setPos(Transform objTrans)
    {
        RaycastHit hit;
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        if (Physics.Raycast(ray, out hit))
        {
            Debug.DrawLine(ray.origin, hit.point);

            if (hit.collider.gameObject.tag == "Platform")
            {
                objTrans.position = hit.collider.gameObject.transform.position;
            }

            if (Input.GetMouseButtonDown(0) && (hit.collider.gameObject.tag == "Platform" || hit.collider.gameObject.tag == objTrans.gameObject.tag))
            {
                buildTurret = false;
                aktiveObjects[aktiveTurretsNumber] = objTrans.gameObject;
                aktiveTurretsNumber++;
            }
        }
    }

    public void spawnTurret()
    {
        if (!buildTurret)
        {
            buildTurret = true;
            Instantiate(turret);
            turretPos = turret.transform;
        }
    }
}